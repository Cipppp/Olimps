t_index] + yellow_cubes[right_index];
        if (blue_cube_value > top_cube_value) 